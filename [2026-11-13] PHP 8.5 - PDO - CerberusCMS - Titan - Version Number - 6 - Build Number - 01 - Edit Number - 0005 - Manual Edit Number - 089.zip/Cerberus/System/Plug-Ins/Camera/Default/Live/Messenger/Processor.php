<?php
/*
 ============================================================================================================
 + ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 + ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 + Cerberus Content Management System
 + ----------------------------------------------------------------------------------------------------------
 + - Author			 : Gary Christopher Johnson of Oildale In Southern California
 + - Company			 : CerberusCMS, Free and Open Source Software
 + - Company Address		 : Oildale In Southern California, United States of America
 + - Electronic Mail Address	 : CerberusCMS6@Proton.me
 + - Document Notes		 : View this file in a non-formatting text editor without word-wrap for the
 +				 : correct display of this programming code and its indentation.
 + ----------------------------------------------------------------------------------------------------------
 +    () --- () () () () -- ()
 +  ()  () () () () -- () ()()()
 +  ------
 + Plug-In Application Module
 + ----------------------------------------------------------------------------------------------------------
 + - This File, Location	 : Root Directory => System => Plug-Ins => Camera => Default => Live =>
 +				 : => Messenger => Processor
 + - This File, Version		 : 0.7.7
 + - This File, Programming Code : Pure Pre-Hyper-Text-Post-Processor
 + - Programming Code Model	 : Procedural, Functional, Object Oriented :: Pre-Order Algebraic
 + -				 :					   :: Pre-Order Logical
 + - Compatibility		 : Extensible-Markup-Language		   :: Version Numbers: 1, 1.1
 + - Compatibility		 : Hyper-Text-Markup-Language		   :: Version Numbers: 1, 2, 3, 4, 5
 + - Compatibility		 : Pre-Hyper-Text-Post-Processor 	   :: Version Numbers: 5, 7, 8
 + - Compatibility		 : Zend Engine				   :: Version Numbers: 3, 4
 + - Official Release Date	 : Saturday, April 19th of 2025
 + ----------------------------------------------------------------------------------------------------------
 + -------------------------------------------------------------------------------      - Titan -
 + --[][]--[][][]--[][][]--[][][]---[][][]--[][][]--[]--[]------[][][]------------   []++++||=======>
 + -[]-----[]------[]--[]--[]---[]--[]------[]--[]--[]--[]------[]----------------
 + -[]-----[]------[]--[]--[]---[]--[]------[]--[]--[]--[]------[]----------------    |'-._/\_.-'|
 + -[]-----[]------[]--[]--[]---[]--[]------[]--[]--[]--[]------[]----------------    |    []    |
 + -[]-----[]------[]--[]--[]---[]--[]------[]--[]--[]--[]------[]----------------    |___-[]-___|
 + -[]-----[][][]--[][][]--[][][]---[][][]--[][][]--[]--[]------[]----------------    |__((**))__|
 + -[]-----[]------[]--[]--[]---[]--[]------[]--[]--[]--[]------[]----------------    \   -[]-   /
 + -[]-----[]------[]--[]--[]---[]--[]------[]--[]--[]--[]------[]------------/-\-     \   []   /
 + -[]-----[]------[]--[]--[]---[]--[]------[]--[]--[]--[]------[]---VERSION--|6|-	\  []  /
 + --[][]--[][][]--[]--[]--[][][]---[][][]--[]--[]--[][][]--[][][]------------\-/-	 '.[].'
 + -------------------------------------------------------------------------------
 + ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ Build Number: 01 ~ Final
 + ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ Edit Number : 0,005
 ============================================================================================================
*/

/*
 ============================================================================================================
 +
 +
 +
 + [ ^ ] Plug-In :: Camera :: Video :: Live :: Messenger :: Processor
 +
 +
 +
 ============================================================================================================
*/

/*
 ============================================================================================================
 +
 + [ @ ] Plug-In :: Camera :: Video :: Live :: Messenger :: Processor :: Variables
 +
 ============================================================================================================
*/

/*
 ============================================================================================================
 + Plug-In :: Camera :: Video :: Live :: Messenger :: Processor :: Variables :: Date
 ============================================================================================================
*/

$_GLOBAL_LOCAL_SERVER_DATE_STANDARD		= date("l-F-j-Y-g-i-s-A");
$_GLOBAL_LOCAL_SERVER_TIME_UNIX			= time();

/*
 ============================================================================================================
 + Plug-In :: Camera :: Video :: Live :: Shouts :: Processor :: Variables :: Cookies
 ============================================================================================================
*/

$_GLOBAL_COOKIE_MEMBER_USERNAME			= $_COOKIE['kernel_member_username'];
$_GLOBAL_COOKIE_MEMBER_PASSWORD			= $_COOKIE['kernel_member_password'];

/*
 ============================================================================================================
 + Plug-In :: Camera :: Video :: Live :: Shouts :: Processor :: Constantly Extract Video Feed
 ============================================================================================================
*/

var_dump($_FILES);

/*
 ============================================================================================================
 + Plug-In :: Camera :: Video :: Live :: Shouts :: Processor :: Move Finished Video File To Backup Directory
 ============================================================================================================
*/

move_uploaded_file($_FILES['blobFile']['tmp_name'], "../../../../../../Temporary/Messenger/Text-File/Clear-Text/Visible/$_Application_Module_Member_Messenger_SQL_LIST_MESSENGER_CLEAR_TEXT_FILE_MESSENGER_ROOM_NAME/Files/Video/Live Video File - $_GLOBAL_LOCAL_SERVER_TIME_UNIX.mp4");

/*
 ============================================================================================================
 + Plug-In :: Camera :: Video :: Live :: Shouts :: Processor :: Copy Finished Video File From Backup Directory To Live Directory
 ============================================================================================================
*/

copy("../../../../../../Temporary/Messenger/Text-File/Clear-Text/Visible/$_Application_Module_Member_Messenger_SQL_LIST_MESSENGER_CLEAR_TEXT_FILE_MESSENGER_ROOM_NAME/Files/Video/Live Video File - $_GLOBAL_LOCAL_SERVER_TIME_UNIX.mp4","../../../../../../Temporary/Messenger/Text-File/Clear-Text/Visible/$_Application_Module_Member_Messenger_SQL_LIST_MESSENGER_CLEAR_TEXT_FILE_MESSENGER_ROOM_NAME/Files/Video/Live Video File - $_GLOBAL_LOCAL_SERVER_TIME_UNIX.mp4");
?>